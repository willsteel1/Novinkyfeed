import json
import requests
import xbmcplugin
import xbmcgui
import sys
import urllib.parse

BASE_URL = "https://kodi-novinky-api.onrender.com/novinky?key=tajnykluc123"
HANDLE = int(sys.argv[1])
ARGS = urllib.parse.parse_qs(sys.argv[2][1:])

def fetch_data():
    try:
        response = requests.get(BASE_URL)
        return response.json()
    except:
        return []

def add_item(item):
    li = xbmcgui.ListItem(label=item["title"])
    li.setInfo("video", {
        "title": item["title"],
        "genre": ", ".join(item.get("genres", [])),
        "plot": item.get("description", ""),
        "year": item.get("date", "")[:4],
    })
    if "poster" in item:
        li.setArt({"thumb": item["poster"], "icon": item["poster"], "poster": item["poster"]})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li, isFolder=False)

def show_main_menu():
    url = sys.argv[0] + "?action=show_novinky"
    li = xbmcgui.ListItem(label="📰 Zobraziť novinky")
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def show_novinky():
    data = fetch_data()
    if not data:
        li = xbmcgui.ListItem(label="❌ Nepodarilo sa načítať novinky")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li, isFolder=False)
    else:
        for item in data:
            add_item(item)
    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == "__main__":
    if ARGS.get("action") == ["show_novinky"]:
        show_novinky()
    else:
        show_main_menu()
